#!/bin/sh
for file in *.cpp; do
    command="g++ -c -g -W -Wall -Weffc++ -Wold-style-cast -pedantic -std=c++11 $file"
    echo $command
    eval $command
    if [ $? -ne 0 ] ; then
        killall build-static.sh
    fi
done

lib="ar -rs libaufgabe6.a *.o"
echo $lib
eval $lib
if [ $? -ne 0 ] ; then
    killall build-static.sh
fi
