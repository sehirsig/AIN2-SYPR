#!/bin/sh
for file in *.cpp; do
    command="g++ -c -fpic -g -W -Wall -Weffc++ -Wold-style-cast -pedantic -std=c++11 $file"
    echo $command
    eval $command
    if [ $? -ne 0 ] ; then
        killall build-dynamic.sh
    fi
done

lib="gcc -shared -o libaufgabe6.so *.o"
echo $lib
eval $lib
if [ $? -ne 0 ] ; then
    killall build-dynamic.sh
fi
